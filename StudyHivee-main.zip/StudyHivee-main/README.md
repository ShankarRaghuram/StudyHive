# StudyHive 🐝

**The Hive of Smarter Study**

StudyHive is an all-in-one academic companion platform designed for students and teachers to collaborate, organize, and excel in their educational journey.

## ✨ Features

### For Students
- **Semesters** - Organize your academic journey semester by semester
- **GPA Calculator** - Calculate and track your GPA with ease
- **Study Plus** - Access and share study materials with your community
- **Focus Time** - Track your study sessions with a built-in timer

### For Teachers
- **Semesters** - View and manage semester-wise course materials
- **Study Plus** - Upload and manage study materials for students

## 🚀 Tech Stack

- **Frontend**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **Backend**: Supabase (Authentication & Database)
- **Icons**: Lucide React

## 📦 Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd StudyHivee
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory with your Supabase credentials:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

4. Run the development server:
```bash
npm run dev
```

The app will be available at `http://localhost:5173`

## 🛠️ Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run typecheck` - Run TypeScript type checking

## 📱 Features Overview

### Authentication
Secure user authentication with role-based access (Student/Teacher) powered by Supabase.

### Semester Management
Organize courses and materials by academic semesters for better structure.

### GPA Calculator
Easy-to-use calculator to track academic performance across semesters.

### Study Materials
Upload, share, and access study materials within the community.

### Focus Timer
Built-in Pomodoro-style timer to help students maintain focus during study sessions.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is open source and available under the MIT License.

## 📧 Contact

For questions or support, please open an issue in the repository.

---

Made with ❤️ by the StudyHive Team
