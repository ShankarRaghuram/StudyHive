-- Create storage bucket for study materials if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('study-materials', 'study-materials', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for study-materials bucket
-- Note: Run these one at a time in Supabase SQL Editor

-- 1. Teachers can upload files
CREATE POLICY "Teachers can upload files"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'study-materials' AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'teacher'
    )
  );

-- 2. Authenticated users can download files
CREATE POLICY "Authenticated users can download files"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'study-materials');

-- 3. Teachers can update their own files
CREATE POLICY "Teachers can update their own files"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'study-materials' AND
    owner = auth.uid() AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'teacher'
    )
  );

-- 4. Teachers can delete their own files
CREATE POLICY "Teachers can delete their own files"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'study-materials' AND
    owner = auth.uid() AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'teacher'
    )
  );
