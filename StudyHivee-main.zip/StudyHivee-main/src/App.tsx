import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Auth from './components/Auth';
import Layout from './components/Layout';
import Home from './pages/Home';
import Semesters from './pages/Semesters';
import GPACalculator from './pages/GPACalculator';
import StudyMaterials from './pages/StudyMaterials';
import FocusTime from './pages/FocusTime';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedSemester, setSelectedSemester] = useState<string | undefined>(undefined);

  const handleNavigate = (page: string, semester?: string) => {
    setCurrentPage(page);
    setSelectedSemester(semester);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#FDB913' }}>
        <div className="text-center">
          <img src="/image.png" alt="StudyHive" className="w-32 h-32 mx-auto mb-4 animate-pulse" />
          <div className="text-2xl font-bold text-black">Loading StudyHive...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={handleNavigate} />;
      case 'semesters':
        return <Semesters onNavigate={handleNavigate} />;
      case 'gpa':
        return <GPACalculator />;
      case 'materials':
        return <StudyMaterials initialSemester={selectedSemester} />;
      case 'focus':
        return <FocusTime />;
      default:
        return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={(page) => handleNavigate(page)}>
      {renderPage()}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
