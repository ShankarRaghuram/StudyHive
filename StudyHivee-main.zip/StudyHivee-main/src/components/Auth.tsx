import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogIn, UserPlus, GraduationCap, BookOpen, ArrowLeft, Eye, EyeOff, RefreshCw, Check, X } from 'lucide-react';

type UserType = 'student' | 'teacher' | null;

interface PasswordStrength {
  score: number;
  label: string;
  color: string;
  suggestions: string[];
}

export default function Auth() {
  const [userType, setUserType] = useState<UserType>(null);
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { signIn, signUp } = useAuth();

  const checkPasswordStrength = (pwd: string): PasswordStrength => {
    let score = 0;
    const suggestions: string[] = [];

    if (pwd.length >= 8) score++;
    else suggestions.push('At least 8 characters');

    if (pwd.length >= 12) score++;
    
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) score++;
    else suggestions.push('Mix of uppercase and lowercase');

    if (/\d/.test(pwd)) score++;
    else suggestions.push('Include numbers');

    if (/[!@#$%^&*(),.?":{}|<>]/.test(pwd)) score++;
    else suggestions.push('Include special characters (!@#$%^&*)');

    if (score <= 1) return { score, label: 'Weak', color: 'bg-red-500', suggestions };
    if (score <= 3) return { score, label: 'Fair', color: 'bg-orange-500', suggestions };
    if (score <= 4) return { score, label: 'Good', color: 'bg-yellow-500', suggestions };
    return { score, label: 'Strong', color: 'bg-green-500', suggestions };
  };

  const generatePassword = () => {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const special = '!@#$%^&*';
    
    const all = lowercase + uppercase + numbers + special;
    let pwd = '';
    
    // Ensure at least one of each type
    pwd += lowercase[Math.floor(Math.random() * lowercase.length)];
    pwd += uppercase[Math.floor(Math.random() * uppercase.length)];
    pwd += numbers[Math.floor(Math.random() * numbers.length)];
    pwd += special[Math.floor(Math.random() * special.length)];
    
    // Fill rest randomly
    for (let i = 4; i < 16; i++) {
      pwd += all[Math.floor(Math.random() * all.length)];
    }
    
    // Shuffle
    pwd = pwd.split('').sort(() => Math.random() - 0.5).join('');
    setPassword(pwd);
  };

  const passwordStrength = !isLogin && password ? checkPasswordStrength(password) : null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validate student email
    if (userType === 'student' && !email.endsWith('.edu.in')) {
      setError('Students must use a .edu.in email address');
      setLoading(false);
      return;
    }

    // Validate teacher email (should not be .edu.in)
    if (userType === 'teacher' && email.endsWith('.edu.in')) {
      setError('Teachers cannot use .edu.in email addresses. Please use your professional email.');
      setLoading(false);
      return;
    }

    // Validate password strength for signup
    if (!isLogin) {
      const strength = checkPasswordStrength(password);
      if (strength.score < 3) {
        setError('Password is too weak. Please use a stronger password or click the refresh icon to generate one.');
        setLoading(false);
        return;
      }
    }

    try {
      if (isLogin) {
        const { error } = await signIn(email, password);
        if (error) setError(error.message);
      } else {
        const { error } = await signUp(email, password, fullName);
        if (error) setError(error.message);
        else setError(`${userType === 'student' ? 'Student' : 'Teacher'} account created! Please check your email to verify.`);
      }
    } catch {
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  // User type selection screen
  if (!userType) {
    return (
      <div className="min-h-screen overflow-y-auto" style={{ background: '#FDB913' }}>
        <div className="absolute inset-0 opacity-10">
          <svg width="100%" height="100%">
            <defs>
              <pattern id="honeycomb" x="0" y="0" width="56" height="100" patternUnits="userSpaceOnUse">
                <polygon points="28,0 56,17 56,50 28,67 0,50 0,17" fill="none" stroke="#000000" strokeWidth="2"/>
                <polygon points="28,67 56,84 56,117 28,134 0,117 0,84" fill="none" stroke="#000000" strokeWidth="2"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#honeycomb)" />
          </svg>
        </div>

        <div className="relative z-10 py-12 px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <img src="/image.png" alt="StudyHive Logo" className="w-32 h-32 mx-auto mb-4 animate-bounce" />
            <h1 className="text-5xl font-bold text-black mb-4">Welcome to StudyHive</h1>
            <p className="text-black text-2xl mb-2">The Hive of Smarter Study</p>
            <p className="text-black text-lg max-w-2xl mx-auto">
              Join thousands of students and teachers collaborating to make education better
            </p>
          </div>

          {/* User Type Selection */}
          <div className="max-w-5xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-black text-center mb-8">Choose Your Role</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <button
                onClick={() => setUserType('student')}
                className="group bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl p-8 border-4 border-black hover:scale-105 transition-all"
              >
                <div className="text-center space-y-4">
                  <div className="w-24 h-24 mx-auto bg-green-400 rounded-full flex items-center justify-center border-4 border-black group-hover:bg-green-500 transition-colors">
                    <GraduationCap className="w-12 h-12 text-black" />
                  </div>
                  <h2 className="text-3xl font-bold text-black">Student</h2>
                  <p className="text-gray-700 text-lg">Access study materials and track your academic progress</p>
                  <div className="pt-4 border-t-2 border-gray-200">
                    <p className="text-sm text-gray-600">Requires .edu.in email</p>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setUserType('teacher')}
                className="group bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl p-8 border-4 border-black hover:scale-105 transition-all"
              >
                <div className="text-center space-y-4">
                  <div className="w-24 h-24 mx-auto bg-blue-400 rounded-full flex items-center justify-center border-4 border-black group-hover:bg-blue-500 transition-colors">
                    <BookOpen className="w-12 h-12 text-black" />
                  </div>
                  <h2 className="text-3xl font-bold text-black">Teacher</h2>
                  <p className="text-gray-700 text-lg">Upload materials and manage student resources</p>
                  <div className="pt-4 border-t-2 border-gray-200">
                    <p className="text-sm text-gray-600">Professional email required</p>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Benefits Section for Students */}
          <div className="max-w-6xl mx-auto mb-16">
            <div className="bg-white/95 backdrop-blur-sm rounded-xl border-4 border-black p-8 shadow-2xl">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-green-400 rounded-full flex items-center justify-center border-4 border-black">
                  <GraduationCap className="w-8 h-8 text-black" />
                </div>
                <h3 className="text-3xl font-bold text-black">Student Benefits</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Access Study Materials</h4>
                    <p className="text-gray-700">Download notes, assignments, and resources uploaded by teachers</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">GPA Calculator</h4>
                    <p className="text-gray-700">Track your grades and calculate your GPA automatically</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Focus Time Tracker</h4>
                    <p className="text-gray-700">Monitor your study sessions with built-in stopwatch</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Semester Organization</h4>
                    <p className="text-gray-700">View subjects and materials organized by semester</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Benefits Section for Teachers */}
          <div className="max-w-6xl mx-auto mb-16">
            <div className="bg-white/95 backdrop-blur-sm rounded-xl border-4 border-black p-8 shadow-2xl">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-blue-400 rounded-full flex items-center justify-center border-4 border-black">
                  <BookOpen className="w-8 h-8 text-black" />
                </div>
                <h3 className="text-3xl font-bold text-black">Teacher Benefits</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Upload Materials</h4>
                    <p className="text-gray-700">Share notes, assignments, and resources with students (up to 50MB)</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Organize by Subject</h4>
                    <p className="text-gray-700">Categorize materials by semester and subject for easy access</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Manage Content</h4>
                    <p className="text-gray-700">Edit and delete your uploaded materials anytime</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center border-2 border-black flex-shrink-0 mt-1">
                    <span className="text-black font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-black text-lg">Track Uploads</h4>
                    <p className="text-gray-700">See all your uploaded materials with "Your Upload" badges</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-xl border-4 border-black p-8 shadow-2xl">
              <h3 className="text-3xl font-bold text-black text-center mb-8">Join Our Growing Community</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center bg-white/90 rounded-lg p-6 border-2 border-black">
                  <div className="text-5xl font-bold text-black mb-2">10K+</div>
                  <div className="text-gray-700 font-semibold">Study Materials</div>
                </div>
                <div className="text-center bg-white/90 rounded-lg p-6 border-2 border-black">
                  <div className="text-5xl font-bold text-black mb-2">5K+</div>
                  <div className="text-gray-700 font-semibold">Active Students</div>
                </div>
                <div className="text-center bg-white/90 rounded-lg p-6 border-2 border-black">
                  <div className="text-5xl font-bold text-black mb-2">500+</div>
                  <div className="text-gray-700 font-semibold">Teachers</div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <p className="text-black text-xl font-semibold">Ready to get started? Choose your role above! 👆</p>
          </div>
        </div>
      </div>
    );
  }

  // Login/Signup form
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#FDB913' }}>
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="honeycomb" x="0" y="0" width="56" height="100" patternUnits="userSpaceOnUse">
              <polygon points="28,0 56,17 56,50 28,67 0,50 0,17" fill="none" stroke="#000000" strokeWidth="2"/>
              <polygon points="28,67 56,84 56,117 28,134 0,117 0,84" fill="none" stroke="#000000" strokeWidth="2"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#honeycomb)" />
        </svg>
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <img src="/image.png" alt="StudyHive Logo" className="w-32 h-32 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-black mb-2">StudyHive</h1>
          <p className="text-black text-lg">The Hive of Smarter Study</p>
        </div>

        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-xl p-8 border-2 border-black">
          <button
            onClick={() => {
              setUserType(null);
              setEmail('');
              setPassword('');
              setFullName('');
              setError('');
            }}
            className="flex items-center text-gray-600 hover:text-black mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to selection
          </button>

          <div className="flex items-center justify-center gap-4 mb-6">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 border-black ${
              userType === 'student' ? 'bg-green-400' : 'bg-blue-400'
            }`}>
              {userType === 'student' ? (
                <GraduationCap className="w-6 h-6 text-black" />
              ) : (
                <BookOpen className="w-6 h-6 text-black" />
              )}
            </div>
            <h2 className="text-2xl font-bold text-black">
              {userType === 'student' ? 'Student' : 'Teacher'} Portal
            </h2>
          </div>
          <div className="flex gap-4 mb-6">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
                isLogin
                  ? 'bg-black text-yellow-400'
                  : 'bg-gray-200 text-black hover:bg-gray-300'
              }`}
            >
              <LogIn className="inline-block w-5 h-5 mr-2" />
              Login
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
                !isLogin
                  ? 'bg-black text-yellow-400'
                  : 'bg-gray-200 text-black hover:bg-gray-300'
              }`}
            >
              <UserPlus className="inline-block w-5 h-5 mr-2" />
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-black font-semibold mb-2">Full Name</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-black font-semibold mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={userType === 'student' ? 'your.name@university.edu.in' : 'your.email@example.com'}
                className="w-full px-4 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                required
              />
              {!isLogin && (
                <p className="text-sm text-gray-600 mt-1">
                  {userType === 'student' ? (
                    <span className="flex items-center text-green-600">
                      <GraduationCap className="w-4 h-4 mr-1" />
                      Must use .edu.in email address
                    </span>
                  ) : (
                    <span className="flex items-center text-blue-600">
                      <BookOpen className="w-4 h-4 mr-1" />
                      Use your professional email
                    </span>
                  )}
                </p>
              )}
            </div>

            <div>
              <label className="block text-black font-semibold mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-2 pr-24 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                  required
                  minLength={8}
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                  {!isLogin && (
                    <button
                      type="button"
                      onClick={generatePassword}
                      className="p-2 hover:bg-gray-100 rounded transition-colors"
                      title="Generate strong password"
                    >
                      <RefreshCw className="w-4 h-4 text-gray-600" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-2 hover:bg-gray-100 rounded transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4 text-gray-600" />
                    ) : (
                      <Eye className="w-4 h-4 text-gray-600" />
                    )}
                  </button>
                </div>
              </div>
              
              {/* Password Strength Indicator */}
              {!isLogin && password && (
                <div className="mt-2 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${passwordStrength?.color} transition-all duration-300`}
                        style={{ width: `${(passwordStrength?.score || 0) * 20}%` }}
                      />
                    </div>
                    <span className={`text-sm font-semibold ${
                      passwordStrength?.score === 5 ? 'text-green-600' :
                      passwordStrength?.score === 4 ? 'text-yellow-600' :
                      passwordStrength?.score === 3 ? 'text-orange-600' :
                      'text-red-600'
                    }`}>
                      {passwordStrength?.label}
                    </span>
                  </div>
                  
                  {passwordStrength && passwordStrength.suggestions.length > 0 && (
                    <div className="text-xs space-y-1">
                      {passwordStrength.suggestions.map((suggestion, index) => (
                        <div key={index} className="flex items-center gap-1 text-gray-600">
                          <X className="w-3 h-3 text-red-500" />
                          <span>{suggestion}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {passwordStrength && passwordStrength.score === 5 && (
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <Check className="w-3 h-3" />
                      <span>Excellent! Your password is strong and secure.</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {error && (
              <div className={`p-3 rounded-lg ${error.includes('created') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-black text-yellow-400 py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors disabled:opacity-50"
            >
              {loading ? 'Processing...' : isLogin ? 'Login' : 'Sign Up'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
