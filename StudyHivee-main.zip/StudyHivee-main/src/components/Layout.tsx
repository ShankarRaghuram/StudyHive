import { ReactNode } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Home, Calendar, Calculator, BookOpen, LogOut, Clock } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Layout({ children, currentPage, onNavigate }: LayoutProps) {
  const { profile, signOut } = useAuth();

  // Different navigation items based on user role
  const studentNavItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'semesters', label: 'Semesters', icon: Calendar },
    { id: 'gpa', label: 'StudyHive GPA', icon: Calculator },
    { id: 'materials', label: 'Study Plus', icon: BookOpen },
    { id: 'focus', label: 'Focus Time', icon: Clock },
  ];

  const teacherNavItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'semesters', label: 'Semesters', icon: Calendar },
    { id: 'materials', label: 'Study Plus', icon: BookOpen },
  ];

  const navItems = profile?.role === 'teacher' ? teacherNavItems : studentNavItems;

  return (
    <div className="min-h-screen" style={{ background: '#FFF9E6' }}>
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="honeycomb-bg" x="0" y="0" width="56" height="100" patternUnits="userSpaceOnUse">
              <polygon points="28,0 56,17 56,50 28,67 0,50 0,17" fill="none" stroke="#000000" strokeWidth="1"/>
              <polygon points="28,67 56,84 56,117 28,134 0,117 0,84" fill="none" stroke="#000000" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#honeycomb-bg)" />
        </svg>
      </div>

      <nav className="relative z-10 border-b-4 border-black" style={{ background: '#FDB913' }}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-4">
              <img src="/image.png" alt="StudyHive" className="w-12 h-12" />
              <div>
                <h1 className="text-2xl font-bold text-black">StudyHive</h1>
                <p className="text-sm text-black">The Hive of Smarter Study</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`flex items-center px-4 py-2 rounded-lg font-semibold transition-all ${
                      currentPage === item.id
                        ? 'bg-black text-yellow-400 shadow-lg'
                        : 'text-black hover:bg-black/10'
                    }`}
                  >
                    <Icon className="w-5 h-5 mr-2" />
                    {item.label}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-black font-semibold">{profile?.full_name}</div>
                <div className="text-sm text-black">
                  {profile?.role === 'teacher' ? 'Teacher' : 'Student'}
                </div>
              </div>
              <button
                onClick={signOut}
                className="flex items-center px-4 py-2 bg-black text-yellow-400 rounded-lg font-semibold hover:bg-gray-800 transition-colors"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
}
