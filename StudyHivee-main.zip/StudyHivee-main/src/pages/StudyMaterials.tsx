import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, StudyMaterial } from '../lib/supabase';
import { BookOpen, Upload, Download, FileText, Image, Film, File, Search, Filter, Trash2 } from 'lucide-react';

interface StudyMaterialsProps {
  initialSemester?: string;
}

export default function StudyMaterials({ initialSemester }: StudyMaterialsProps) {
  const { profile } = useAuth();
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSemester, setFilterSemester] = useState(initialSemester || 'all');
  const [showUploadForm, setShowUploadForm] = useState(false);

  const [uploadForm, setUploadForm] = useState({
    title: '',
    description: '',
    semester: '1',
    subject: '',
    file: null as File | null,
  });

  // Subject list for each semester
  const semesterSubjects: { [key: string]: string[] } = {
    '1': ['Mathematics I', 'Physics', 'Chemistry', 'Engineering Drawing', 'Programming Basics', 'Communication Skills'],
    '2': ['Mathematics II', 'Electronics', 'Mechanics', 'Data Structures', 'Digital Logic', 'Environmental Science'],
    '3': ['Mathematics III', 'Database Systems', 'Computer Networks', 'Operating Systems', 'Object Oriented Programming', 'Discrete Mathematics', 'Technical Writing'],
    '4': ['Algorithm Design', 'Software Engineering', 'Web Technologies', 'Computer Architecture', 'Theory of Computation', 'Microprocessors', 'Economics'],
    '5': ['Machine Learning', 'Compiler Design', 'Computer Graphics', 'Cloud Computing', 'Mobile App Development', 'Cryptography'],
    '6': ['Artificial Intelligence', 'Big Data Analytics', 'IoT', 'Blockchain', 'Cyber Security', 'Project Management'],
    '7': ['Deep Learning', 'DevOps', 'Advanced Databases', 'Distributed Systems', 'Elective I'],
    '8': ['Capstone Project', 'Industry Internship', 'Elective II', 'Seminar'],
  };

  useEffect(() => {
    loadMaterials();
  }, []);

  useEffect(() => {
    if (initialSemester) {
      setFilterSemester(initialSemester);
    }
  }, [initialSemester]);

  const loadMaterials = async () => {
    try {
      const { data, error } = await supabase
        .from('study_materials')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMaterials(data || []);
    } catch (error) {
      console.error('Error loading materials:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadForm.file || !profile) return;

    // Validate file size (max 50MB)
    const maxSize = 50 * 1024 * 1024;
    if (uploadForm.file.size > maxSize) {
      alert('File size must be less than 50MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = uploadForm.file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${profile.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('study-materials')
        .upload(filePath, uploadForm.file);

      if (uploadError) throw uploadError;

      const { error: insertError } = await supabase
        .from('study_materials')
        .insert({
          title: uploadForm.title,
          description: uploadForm.description,
          file_url: filePath,
          file_type: uploadForm.file.type,
          file_size: uploadForm.file.size,
          semester: uploadForm.semester,
          subject: uploadForm.subject,
          uploaded_by: profile.id,
        });

      if (insertError) throw insertError;

      setUploadForm({
        title: '',
        description: '',
        semester: '1',
        subject: '',
        file: null,
      });
      setShowUploadForm(false);
      loadMaterials();
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDownload = async (material: StudyMaterial) => {
    try {
      // Download file from storage
      const { data, error } = await supabase.storage
        .from('study-materials')
        .download(material.file_url);

      if (error) {
        console.error('Storage download error:', error);
        throw new Error(`Failed to download: ${error.message}`);
      }

      if (!data) {
        throw new Error('No file data received');
      }

      // Get file extension from file_type or file_url
      let fileName = material.title;
      if (material.file_type) {
        const extension = material.file_type.split('/')[1];
        if (extension && !fileName.endsWith(`.${extension}`)) {
          fileName += `.${extension}`;
        }
      } else if (material.file_url.includes('.')) {
        const urlExtension = material.file_url.split('.').pop();
        if (urlExtension && !fileName.endsWith(`.${urlExtension}`)) {
          fileName += `.${urlExtension}`;
        }
      }

      // Create download link
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      console.log('File downloaded successfully:', fileName);
    } catch (error) {
      console.error('Error downloading file:', error);
      const errorMessage = error instanceof Error ? error.message : 'Please try again.';
      alert(`Error downloading file: ${errorMessage}\n\nNote: Make sure the storage bucket is created in Supabase.`);
    }
  };

  const handleDelete = async (material: StudyMaterial) => {
    const confirmMessage = `Are you sure you want to delete "${material.title}"?\n\nThis action cannot be undone.`;
    if (!confirm(confirmMessage)) return;

    try {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('study-materials')
        .remove([material.file_url]);

      if (storageError) {
        console.error('Storage deletion error:', storageError);
        // Continue even if storage deletion fails
      }

      // Delete from database
      const { error: dbError } = await supabase
        .from('study_materials')
        .delete()
        .eq('id', material.id);

      if (dbError) throw dbError;

      alert('Material deleted successfully!');
      loadMaterials();
    } catch (error) {
      console.error('Error deleting material:', error);
      alert('Error deleting material. Please try again.');
    }
  };

  const getFileIcon = (fileType: string | null) => {
    if (!fileType) return File;
    if (fileType.startsWith('image/')) return Image;
    if (fileType.startsWith('video/')) return Film;
    return FileText;
  };

  const filteredMaterials = materials.filter((material) => {
    const matchesSearch =
      material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.subject?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSemester =
      filterSemester === 'all' || material.semester === filterSemester;
    return matchesSearch && matchesSemester;
  });

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-400 border-4 border-black">
          <BookOpen className="w-10 h-10 text-black" />
        </div>
        <h1 className="text-4xl font-bold text-black">Study Plus</h1>
        <p className="text-lg text-gray-700">
          {profile?.role === 'teacher'
            ? 'Upload and manage study materials'
            : 'Access study materials shared by teachers'}
        </p>
      </div>

      <div className="bg-white rounded-xl border-4 border-black p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search materials..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-600" />
            <select
              value={filterSemester}
              onChange={(e) => setFilterSemester(e.target.value)}
              className="px-4 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
            >
              <option value="all">All Semesters</option>
              {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                <option key={sem} value={sem.toString()}>
                  Semester {sem}
                </option>
              ))}
            </select>
          </div>
          {profile?.role === 'teacher' && (
            <button
              onClick={() => setShowUploadForm(!showUploadForm)}
              className="flex items-center px-6 py-2 bg-yellow-400 text-black font-bold rounded-lg border-2 border-black hover:bg-yellow-500 transition-colors"
            >
              <Upload className="w-5 h-5 mr-2" />
              Upload Material
            </button>
          )}
        </div>

        {showUploadForm && profile?.role === 'teacher' && (
          <form onSubmit={handleUpload} className="mb-6 p-6 bg-yellow-50 rounded-lg border-2 border-yellow-400">
            <h3 className="text-xl font-bold text-black mb-4">Upload New Material</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-black mb-1">Title</label>
                <input
                  type="text"
                  value={uploadForm.title}
                  onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                  required
                  className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-black mb-1">Semester</label>
                <select
                  value={uploadForm.semester}
                  onChange={(e) => setUploadForm({ ...uploadForm, semester: e.target.value, subject: '' })}
                  className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                    <option key={sem} value={sem.toString()}>
                      Semester {sem}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-black mb-1">Subject</label>
                <select
                  value={uploadForm.subject}
                  onChange={(e) => setUploadForm({ ...uploadForm, subject: e.target.value })}
                  required
                  className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                >
                  <option value="">Select a subject</option>
                  {semesterSubjects[uploadForm.semester]?.map((subject) => (
                    <option key={subject} value={subject}>
                      {subject}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-black mb-1">File</label>
                <input
                  type="file"
                  onChange={(e) =>
                    setUploadForm({ ...uploadForm, file: e.target.files?.[0] || null })
                  }
                  required
                  className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-black mb-1">Description</label>
                <textarea
                  value={uploadForm.description}
                  onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                />
              </div>
            </div>
            <div className="flex gap-4 mt-4">
              <button
                type="submit"
                disabled={uploading}
                className="px-6 py-2 bg-black text-yellow-400 font-bold rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50"
              >
                {uploading ? 'Uploading...' : 'Upload'}
              </button>
              <button
                type="button"
                onClick={() => setShowUploadForm(false)}
                className="px-6 py-2 bg-gray-200 text-black font-bold rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="text-lg text-gray-600">Loading materials...</div>
          </div>
        ) : filteredMaterials.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <div className="text-lg text-gray-600">No materials found</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMaterials.map((material) => {
              const FileIcon = getFileIcon(material.file_type);
              return (
                <div
                  key={material.id}
                  className="p-4 bg-gradient-to-br from-yellow-50 to-white rounded-lg border-2 border-yellow-400 hover:shadow-lg transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center border-2 border-black flex-shrink-0">
                      <FileIcon className="w-6 h-6 text-black" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-black truncate">{material.title}</h3>
                        {profile?.role === 'teacher' && material.uploaded_by === profile.id && (
                          <span className="text-xs px-2 py-0.5 bg-blue-500 text-white rounded font-semibold">
                            Your Upload
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 truncate">{material.subject}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs px-2 py-1 bg-yellow-400 text-black rounded font-semibold">
                          Sem {material.semester}
                        </span>
                        {material.file_size && (
                          <span className="text-xs text-gray-500">
                            {(material.file_size / 1024 / 1024).toFixed(2)} MB
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  {material.description && (
                    <p className="text-sm text-gray-600 mt-2 line-clamp-2">{material.description}</p>
                  )}
                  <div className="flex gap-2 mt-4">
                    {/* Everyone can download materials */}
                    <button
                      onClick={() => handleDownload(material)}
                      className="flex-1 flex items-center justify-center px-3 py-2 bg-black text-yellow-400 font-semibold rounded-lg hover:bg-gray-800 transition-colors"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </button>
                    
                    {/* Teachers can delete their own uploads */}
                    {profile?.role === 'teacher' && material.uploaded_by === profile.id && (
                      <button
                        onClick={() => handleDelete(material)}
                        className="flex items-center justify-center px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition-colors"
                        title="Delete this material"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
