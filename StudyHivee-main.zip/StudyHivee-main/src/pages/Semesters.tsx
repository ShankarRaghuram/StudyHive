import { useState, useEffect } from 'react';
import { Calendar, BookOpen, Clock, Award, ArrowLeft, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Semester {
  id: number;
  name: string;
  subjects: string[];
  materials: number;
  status: string;
}

interface SemesterPageProps {
  onNavigate?: (page: string, semester?: string) => void;
}

export default function Semesters({ onNavigate }: SemesterPageProps) {
  const [selectedSemester, setSelectedSemester] = useState<Semester | null>(null);
  const [materialCounts, setMaterialCounts] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    loadMaterialCounts();
  }, []);

  const loadMaterialCounts = async () => {
    try {
      const { data, error } = await supabase
        .from('study_materials')
        .select('semester');

      if (error) throw error;

      const counts: { [key: string]: number } = {};
      data?.forEach((item) => {
        if (item.semester) {
          counts[item.semester] = (counts[item.semester] || 0) + 1;
        }
      });

      setMaterialCounts(counts);
    } catch (error) {
      console.error('Error loading material counts:', error);
    }
  };

  const semesters: Semester[] = [
    { 
      id: 1, 
      name: 'Semester 1', 
      subjects: ['Mathematics I', 'Physics', 'Chemistry', 'Engineering Drawing', 'Programming Basics', 'Communication Skills'],
      materials: materialCounts['1'] || 0, 
      status: 'Completed' 
    },
    { 
      id: 2, 
      name: 'Semester 2', 
      subjects: ['Mathematics II', 'Electronics', 'Mechanics', 'Data Structures', 'Digital Logic', 'Environmental Science'],
      materials: materialCounts['2'] || 0, 
      status: 'Completed' 
    },
    { 
      id: 3, 
      name: 'Semester 3', 
      subjects: ['Mathematics III', 'Database Systems', 'Computer Networks', 'Operating Systems', 'Object Oriented Programming', 'Discrete Mathematics', 'Technical Writing'],
      materials: materialCounts['3'] || 0, 
      status: 'In Progress' 
    },
    { 
      id: 4, 
      name: 'Semester 4', 
      subjects: ['Algorithm Design', 'Software Engineering', 'Web Technologies', 'Computer Architecture', 'Theory of Computation', 'Microprocessors', 'Economics'],
      materials: materialCounts['4'] || 0, 
      status: 'Upcoming' 
    },
    { 
      id: 5, 
      name: 'Semester 5', 
      subjects: ['Machine Learning', 'Compiler Design', 'Computer Graphics', 'Cloud Computing', 'Mobile App Development', 'Cryptography'],
      materials: materialCounts['5'] || 0, 
      status: 'Upcoming' 
    },
    { 
      id: 6, 
      name: 'Semester 6', 
      subjects: ['Artificial Intelligence', 'Big Data Analytics', 'IoT', 'Blockchain', 'Cyber Security', 'Project Management'],
      materials: materialCounts['6'] || 0, 
      status: 'Upcoming' 
    },
    { 
      id: 7, 
      name: 'Semester 7', 
      subjects: ['Deep Learning', 'DevOps', 'Advanced Databases', 'Distributed Systems', 'Elective I'],
      materials: materialCounts['7'] || 0, 
      status: 'Upcoming' 
    },
    { 
      id: 8, 
      name: 'Semester 8', 
      subjects: ['Capstone Project', 'Industry Internship', 'Elective II', 'Seminar'],
      materials: materialCounts['8'] || 0, 
      status: 'Upcoming' 
    },
  ];

  const totalMaterials = Object.values(materialCounts).reduce((sum, count) => sum + count, 0);
  const completedSemesters = semesters.filter(s => s.status === 'Completed').length;
  const inProgressSemesters = semesters.filter(s => s.status === 'In Progress').length;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-500';
      case 'In Progress':
        return 'bg-yellow-500';
      case 'Upcoming':
        return 'bg-gray-400';
      default:
        return 'bg-gray-400';
    }
  };

  // Show semester details view
  if (selectedSemester) {
    return (
      <div className="space-y-8">
        <button
          onClick={() => setSelectedSemester(null)}
          className="flex items-center text-gray-700 hover:text-black font-semibold transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to All Semesters
        </button>

        <div className="bg-white rounded-xl border-4 border-black p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-yellow-400 flex items-center justify-center border-4 border-black font-bold text-2xl">
                {selectedSemester.id}
              </div>
              <div>
                <h1 className="text-4xl font-bold text-black">{selectedSemester.name}</h1>
                <div className="flex items-center mt-2">
                  <span className={`inline-block w-3 h-3 rounded-full ${getStatusColor(selectedSemester.status)} mr-2`} />
                  <span className="text-lg font-semibold text-gray-700">{selectedSemester.status}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-black">{selectedSemester.materials}</div>
              <div className="text-gray-600">Study Materials</div>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="text-2xl font-bold text-black mb-4">Subjects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {selectedSemester.subjects.map((subject, index) => (
                <div
                  key={index}
                  className="p-4 bg-yellow-50 rounded-lg border-2 border-yellow-400 hover:border-yellow-600 transition-all hover:shadow-md"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center border-2 border-black font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-black">{subject}</h3>
                      <p className="text-sm text-gray-600">Click to view materials</p>
                    </div>
                    <button
                      onClick={() => onNavigate?.('materials', selectedSemester.id.toString())}
                      className="text-yellow-600 hover:text-yellow-700"
                    >
                      <FileText className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg border-4 border-black p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-black mb-2">Ready to Study?</h3>
                <p className="text-black">Access all materials for {selectedSemester.name}</p>
              </div>
              <button 
                onClick={() => onNavigate?.('materials', selectedSemester.id.toString())}
                className="px-6 py-3 bg-black text-yellow-400 font-bold rounded-lg hover:bg-gray-800 transition-colors"
              >
                View All Materials
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show all semesters grid view
  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-400 border-4 border-black">
          <Calendar className="w-10 h-10 text-black" />
        </div>
        <h1 className="text-4xl font-bold text-black">Academic Semesters</h1>
        <p className="text-lg text-gray-700">Track your progress through each semester</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {semesters.map((semester) => (
          <div
            key={semester.id}
            className="bg-white rounded-xl border-4 border-black p-6 hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-black">{semester.name}</h3>
                  <div className="flex items-center mt-2">
                    <span
                      className={`inline-block w-3 h-3 rounded-full ${getStatusColor(semester.status)} mr-2`}
                    />
                    <span className="text-sm font-semibold text-gray-700">{semester.status}</span>
                  </div>
                </div>
                <div className="w-12 h-12 rounded-full bg-yellow-400 flex items-center justify-center border-2 border-black font-bold text-xl">
                  {semester.id}
                </div>
              </div>

              <div className="space-y-2 pt-4 border-t-2 border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-700">
                    <BookOpen className="w-5 h-5 mr-2" />
                    <span className="text-sm">Subjects</span>
                  </div>
                  <span className="font-bold text-black">{semester.subjects.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-700">
                    <Award className="w-5 h-5 mr-2" />
                    <span className="text-sm">Materials</span>
                  </div>
                  <span className="font-bold text-black">{semester.materials}</span>
                </div>
              </div>

              <button 
                onClick={() => setSelectedSemester(semester)}
                className="w-full bg-yellow-400 text-black font-bold py-2 rounded-lg border-2 border-black hover:bg-yellow-500 transition-colors"
              >
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border-4 border-black p-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center p-6 bg-yellow-50 rounded-lg border-2 border-yellow-400">
            <Clock className="w-12 h-12 mx-auto mb-3 text-yellow-600" />
            <div className="text-3xl font-bold text-black mb-2">8</div>
            <div className="text-gray-700 font-semibold">Total Semesters</div>
          </div>
          <div className="text-center p-6 bg-green-50 rounded-lg border-2 border-green-400">
            <Award className="w-12 h-12 mx-auto mb-3 text-green-600" />
            <div className="text-3xl font-bold text-black mb-2">{completedSemesters}</div>
            <div className="text-gray-700 font-semibold">Completed</div>
          </div>
          <div className="text-center p-6 bg-orange-50 rounded-lg border-2 border-orange-400">
            <Calendar className="w-12 h-12 mx-auto mb-3 text-orange-600" />
            <div className="text-3xl font-bold text-black mb-2">{inProgressSemesters}</div>
            <div className="text-gray-700 font-semibold">In Progress</div>
          </div>
          <div className="text-center p-6 bg-blue-50 rounded-lg border-2 border-blue-400">
            <BookOpen className="w-12 h-12 mx-auto mb-3 text-blue-600" />
            <div className="text-3xl font-bold text-black mb-2">{totalMaterials}</div>
            <div className="text-gray-700 font-semibold">Total Materials</div>
          </div>
        </div>
      </div>
    </div>
  );
}
