import { useState } from 'react';
import { Calculator, Plus, Trash2, Award } from 'lucide-react';

interface Course {
  id: number;
  name: string;
  credits: number;
  grade: string;
}

export default function GPACalculator() {
  const [courses, setCourses] = useState<Course[]>([
    { id: 1, name: '', credits: 3, grade: 'A' },
  ]);
  const [nextId, setNextId] = useState(2);

  const gradePoints: { [key: string]: number } = {
    'A+': 10,
    'A': 9,
    'B+': 8,
    'B': 7,
    'C+': 6,
    'C': 5,
    'D': 4,
    'F': 0,
  };

  const addCourse = () => {
    setCourses([...courses, { id: nextId, name: '', credits: 3, grade: 'A' }]);
    setNextId(nextId + 1);
  };

  const removeCourse = (id: number) => {
    if (courses.length > 1) {
      setCourses(courses.filter((course) => course.id !== id));
    }
  };

  const updateCourse = (id: number, field: keyof Course, value: string | number) => {
    setCourses(
      courses.map((course) =>
        course.id === id ? { ...course, [field]: value } : course
      )
    );
  };

  const calculateGPA = () => {
    let totalPoints = 0;
    let totalCredits = 0;

    courses.forEach((course) => {
      const points = gradePoints[course.grade] * course.credits;
      totalPoints += points;
      totalCredits += course.credits;
    });

    return totalCredits > 0 ? (totalPoints / totalCredits).toFixed(2) : '0.00';
  };

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-400 border-4 border-black">
          <Calculator className="w-10 h-10 text-black" />
        </div>
        <h1 className="text-4xl font-bold text-black">StudyHive GPA Calculator</h1>
        <p className="text-lg text-gray-700">Calculate your Grade Point Average easily</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border-4 border-black p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-black">Your Courses</h2>
              <button
                onClick={addCourse}
                className="flex items-center px-4 py-2 bg-yellow-400 text-black font-bold rounded-lg border-2 border-black hover:bg-yellow-500 transition-colors"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Course
              </button>
            </div>

            <div className="space-y-4">
              {courses.map((course, index) => (
                <div
                  key={course.id}
                  className="p-4 bg-yellow-50 rounded-lg border-2 border-yellow-400"
                >
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-5">
                      <label className="block text-sm font-semibold text-black mb-1">
                        Course Name
                      </label>
                      <input
                        type="text"
                        value={course.name}
                        onChange={(e) => updateCourse(course.id, 'name', e.target.value)}
                        placeholder={`Course ${index + 1}`}
                        className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                      />
                    </div>
                    <div className="col-span-3">
                      <label className="block text-sm font-semibold text-black mb-1">
                        Credits
                      </label>
                      <input
                        type="number"
                        value={course.credits}
                        onChange={(e) =>
                          updateCourse(course.id, 'credits', parseInt(e.target.value) || 0)
                        }
                        min="1"
                        max="6"
                        className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                      />
                    </div>
                    <div className="col-span-3">
                      <label className="block text-sm font-semibold text-black mb-1">
                        Grade
                      </label>
                      <select
                        value={course.grade}
                        onChange={(e) => updateCourse(course.id, 'grade', e.target.value)}
                        className="w-full px-3 py-2 border-2 border-black rounded-lg focus:outline-none focus:border-yellow-500"
                      >
                        {Object.keys(gradePoints).map((grade) => (
                          <option key={grade} value={grade}>
                            {grade}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-span-1 flex items-end justify-center">
                      <button
                        onClick={() => removeCourse(course.id)}
                        disabled={courses.length === 1}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-xl border-4 border-black p-6">
            <div className="text-center space-y-4">
              <Award className="w-16 h-16 mx-auto text-black" />
              <div>
                <div className="text-sm font-semibold text-black mb-2">Your GPA</div>
                <div className="text-6xl font-bold text-black">{calculateGPA()}</div>
              </div>
              <div className="pt-4 border-t-2 border-black/20">
                <div className="text-sm text-black">
                  Based on {courses.reduce((sum, c) => sum + c.credits, 0)} credits
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border-4 border-black p-6">
            <h3 className="text-lg font-bold text-black mb-4">Grading Scale</h3>
            <div className="space-y-2">
              {Object.entries(gradePoints).map(([grade, points]) => (
                <div key={grade} className="flex justify-between items-center py-2 border-b border-gray-200 last:border-0">
                  <span className="font-semibold text-black">{grade}</span>
                  <span className="text-gray-700">{points} points</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
