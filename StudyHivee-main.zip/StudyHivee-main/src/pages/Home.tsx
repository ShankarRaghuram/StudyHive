import { Calendar, Calculator, BookOpen, Sparkles, Clock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const studentFeatures = [
    {
      id: 'semesters',
      title: 'Semesters',
      description: 'Organize your academic journey semester by semester',
      icon: Calendar,
      color: '#FDB913',
    },
    {
      id: 'gpa',
      title: 'StudyHive GPA Calculator',
      description: 'Calculate and track your GPA with ease',
      icon: Calculator,
      color: '#FFD700',
    },
    {
      id: 'materials',
      title: 'Study Plus',
      description: 'Access and share study materials with your community',
      icon: BookOpen,
      color: '#FFA500',
    },
    {
      id: 'focus',
      title: 'Focus Time',
      description: 'Track your study sessions with a built-in timer',
      icon: Clock,
      color: '#FF6B6B',
    },
  ];

  const teacherFeatures = [
    {
      id: 'semesters',
      title: 'Semesters',
      description: 'View and manage semester-wise course materials',
      icon: Calendar,
      color: '#FDB913',
    },
    {
      id: 'materials',
      title: 'Study Plus',
      description: 'Upload and manage study materials for students',
      icon: BookOpen,
      color: '#FFA500',
    },
  ];

  const { profile } = useAuth();
  const features = profile?.role === 'teacher' ? teacherFeatures : studentFeatures;

  return (
    <div className="space-y-12">
      <div className="text-center space-y-4">
        <div className="inline-block p-6 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 shadow-xl">
          <img src="/image.png" alt="StudyHive" className="w-32 h-32" />
        </div>
        <h1 className="text-5xl font-bold text-black">Welcome to StudyHive</h1>
        <p className="text-2xl text-gray-700">The Hive of Smarter Study</p>
        <div className="flex items-center justify-center space-x-2 text-lg text-gray-600">
          <Sparkles className="w-6 h-6 text-yellow-600" />
          <span>Your all-in-one academic companion</span>
          <Sparkles className="w-6 h-6 text-yellow-600" />
        </div>
      </div>

      <div className={`grid grid-cols-1 ${profile?.role === 'teacher' ? 'md:grid-cols-2' : 'md:grid-cols-2 lg:grid-cols-4'} gap-8`}>
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <button
              key={feature.id}
              onClick={() => onNavigate(feature.id)}
              className="group relative p-8 rounded-2xl border-4 border-black bg-white hover:shadow-2xl transition-all duration-300 hover:scale-105"
            >
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-10 transition-opacity"
                style={{ background: feature.color }}
              />
              <div className="relative space-y-4">
                <div
                  className="w-20 h-20 mx-auto rounded-full flex items-center justify-center border-4 border-black"
                  style={{ background: feature.color }}
                >
                  <Icon className="w-10 h-10 text-black" />
                </div>
                <h3 className="text-2xl font-bold text-black">{feature.title}</h3>
                <p className="text-gray-700">{feature.description}</p>
              </div>
            </button>
          );
        })}
      </div>

      <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-2xl border-4 border-black p-8 shadow-xl">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold text-black">
            {profile?.role === 'teacher' ? 'Empower Your Students' : 'Ready to Boost Your Studies?'}
          </h2>
          <p className="text-lg text-black">
            {profile?.role === 'teacher' 
              ? 'Share knowledge and resources with students across all semesters'
              : 'Join thousands of students and teachers collaborating in the StudyHive community'
            }
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <div className="bg-white/90 rounded-lg px-6 py-3 border-2 border-black">
              <div className="text-3xl font-bold text-black">10K+</div>
              <div className="text-sm text-gray-700">Study Materials</div>
            </div>
            <div className="bg-white/90 rounded-lg px-6 py-3 border-2 border-black">
              <div className="text-3xl font-bold text-black">5K+</div>
              <div className="text-sm text-gray-700">Active Students</div>
            </div>
            <div className="bg-white/90 rounded-lg px-6 py-3 border-2 border-black">
              <div className="text-3xl font-bold text-black">500+</div>
              <div className="text-sm text-gray-700">Teachers</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
