import { useState, useEffect, useRef } from 'react';
import { Clock, Play, Pause, RotateCcw, Target, TrendingUp } from 'lucide-react';

export default function FocusTime() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [sessions, setSessions] = useState<number[]>([]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartPause = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    if (time > 0) {
      setSessions([...sessions, time]);
    }
    setIsRunning(false);
    setTime(0);
  };

  const totalStudyTime = sessions.reduce((acc, session) => acc + session, 0);
  const averageSession = sessions.length > 0 ? Math.floor(totalStudyTime / sessions.length) : 0;

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-400 border-4 border-black">
          <Clock className="w-10 h-10 text-black" />
        </div>
        <h1 className="text-4xl font-bold text-black">Focus Time</h1>
        <p className="text-lg text-gray-700">Track your study sessions and stay focused</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Timer */}
        <div className="lg:col-span-2">
          <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl border-4 border-black p-12 shadow-xl">
            <div className="text-center space-y-8">
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-white border-4 border-black">
                <Clock className="w-16 h-16 text-black" />
              </div>
              
              <div className="text-8xl font-bold text-black font-mono">
                {formatTime(time)}
              </div>

              <div className="flex justify-center gap-4">
                <button
                  onClick={handleStartPause}
                  className={`flex items-center px-8 py-4 rounded-xl font-bold text-xl border-4 border-black transition-all hover:scale-105 ${
                    isRunning
                      ? 'bg-orange-500 text-white hover:bg-orange-600'
                      : 'bg-green-500 text-white hover:bg-green-600'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <Pause className="w-6 h-6 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-6 h-6 mr-2" />
                      Start
                    </>
                  )}
                </button>

                <button
                  onClick={handleReset}
                  disabled={time === 0}
                  className="flex items-center px-8 py-4 bg-black text-yellow-400 rounded-xl font-bold text-xl border-4 border-black hover:bg-gray-800 transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <RotateCcw className="w-6 h-6 mr-2" />
                  Reset
                </button>
              </div>

              {isRunning && (
                <div className="flex items-center justify-center gap-2 text-black text-lg animate-pulse">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-ping" />
                  <span className="font-semibold">Focus Mode Active</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Tips */}
          <div className="mt-6 bg-white rounded-xl border-4 border-black p-6">
            <h3 className="text-xl font-bold text-black mb-4 flex items-center">
              <Target className="w-6 h-6 mr-2" />
              Focus Tips
            </h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">•</span>
                <span>Take a 5-minute break every 25 minutes (Pomodoro Technique)</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">•</span>
                <span>Keep your phone away during focus sessions</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">•</span>
                <span>Stay hydrated and maintain good posture</span>
              </li>
              <li className="flex items-start">
                <span className="text-yellow-600 mr-2">•</span>
                <span>Set specific goals for each study session</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Stats Sidebar */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border-4 border-black p-6">
            <h3 className="text-xl font-bold text-black mb-4 flex items-center">
              <TrendingUp className="w-6 h-6 mr-2" />
              Today's Stats
            </h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border-2 border-green-400">
                <div className="text-sm text-gray-600 mb-1">Current Session</div>
                <div className="text-3xl font-bold text-black">{formatTime(time)}</div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg border-2 border-blue-400">
                <div className="text-sm text-gray-600 mb-1">Total Study Time</div>
                <div className="text-3xl font-bold text-black">{formatTime(totalStudyTime)}</div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg border-2 border-purple-400">
                <div className="text-sm text-gray-600 mb-1">Sessions Completed</div>
                <div className="text-3xl font-bold text-black">{sessions.length}</div>
              </div>

              <div className="p-4 bg-orange-50 rounded-lg border-2 border-orange-400">
                <div className="text-sm text-gray-600 mb-1">Average Session</div>
                <div className="text-3xl font-bold text-black">{formatTime(averageSession)}</div>
              </div>
            </div>
          </div>

          {/* Recent Sessions */}
          {sessions.length > 0 && (
            <div className="bg-white rounded-xl border-4 border-black p-6">
              <h3 className="text-xl font-bold text-black mb-4">Recent Sessions</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {sessions.slice().reverse().map((session, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border-2 border-yellow-400"
                  >
                    <span className="text-sm font-semibold text-gray-700">
                      Session {sessions.length - index}
                    </span>
                    <span className="text-lg font-bold text-black">{formatTime(session)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
